/**
 * 
 */
/**
 * 
 */
module AlgoritmoFilosofos {
}